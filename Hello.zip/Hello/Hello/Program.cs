﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Hello
{
    class Program
    {
        static void Main(string[] args)
        {
            string fname;
            string lname;
            int age;
            int PhoneNumber;
            string address;
            string Email;

            
            Console.WriteLine("Pleas entert your First name");
            fname = Console.ReadLine();

            Console.WriteLine("pleas entert your last name ");
            lname = Console.ReadLine();
            Console.WriteLine("pleas entert your age");
            age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("pleas entert your Phone number");
            PhoneNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Pleas enter your Address");

            address = Console.ReadLine();
            Console.WriteLine("Plaeas enter your email");
            Email = Console.ReadLine();
            Console.WriteLine("...................Outupt........................");
            Console.WriteLine("Name: " + fname + "\t" + lname );
            Console.WriteLine("Age :" +age);
            Console.WriteLine("Address: "+address);
            Console.WriteLine("Phone number:"+ PhoneNumber);
            Console.WriteLine("E-mail:" +Email);
            Console.ReadLine();
             
        }
    }
}
